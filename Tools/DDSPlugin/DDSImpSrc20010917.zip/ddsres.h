//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dds.rc
//
#define IDS_DDS                         1
#define IDS_BITMAP_IO                   2
#define IDS_DDS_FILE                    3
#define IDS_UNSUPPORTED                 4
#define IDS_CONVERT_ERROR               5
#define IDS_DDS_DESC                    6
#define IDS_NONPOWEROF2_ERROR           7
#define IDS_UNSUPPORTEDFORMAT_ERROR     8
#define IDD_DDS_ABOUT                   101
#define IDD_DDS_CONTROL                 102
#define IDD_DDS_CONFIG                  102
#define IDC_DDS_PALETTE                 1000
#define IDC_DDS_DXT1                    1000
#define IDC_RAD_NTSC                    1001
#define IDC_RAD_24                      1001
#define IDC_DDS_RGB24                   1001
#define IDC_DDS_ARGB8888                1001
#define IDC_RAD_PAL                     1002
#define IDC_RAD_8                       1002
#define IDC_DDS_DXT3                    1002
#define IDC_EDIT_X                      1003
#define IDC_DDS_DXT1ALPHA               1003
#define IDC_EDIT_Y                      1004
#define IDC_DDS_DXT5                    1004
#define IDC_RAD_CUSTOM                  1005
#define IDC_DDS_ARGB1555                1005
#define IDC_DDS_ARGB4444                1006
#define IDC_DDS_RGB565                  1007
#define IDC_DDS_DITHER                  1008
#define IDC_DDS_MIPMAPS                 1009
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
