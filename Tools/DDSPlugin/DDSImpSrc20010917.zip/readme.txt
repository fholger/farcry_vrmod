DDSImp  --  .DDS bitmap importer for MAX 3.1
Copyright 2001 Treyarch LLC

This source code is provided without support, instruction, or implied warranty of any
kind.  Treyarch, LLC and Sean L. Palmer make no guarantee of its fitness for a particular purpose and are
not liable under any circumstances for any damages or loss whatsoever arising
from the use or inability to use this file or items derived from it.

This plugin uses NVIDIA's dxtlib compression library, which is 
Copyright (C) 1999, 2000 NVIDIA Corporation
This file is provided without support, instruction, or implied warranty of any
kind.  NVIDIA makes no guarantee of its fitness for a particular purpose and is
not liable under any circumstances for any damages or loss whatsoever arising
from the use or inability to use this file or items derived from it.

Portions derived from MAX 3 sample code and as such may be copyright Discreet, Kinetix, and/or Autodesk.
Assumption is made that they do not mind distribution of such portions since nothing can be found 
in the SDK which contraindicates such usage.  In any case they don't endorse or warrant this source
code either.

You will need a licensed copy of the 3D Studio MAX R3 SDK to compile this source code.

Any questions or problems can be directed at spalmer@treyarch.com, but I'm not able to provide much in 
the way of support as my time is limited.

I hope the lawyers are all happy now.

Enjoy! Hope it helps!

Sean L. Palmer
