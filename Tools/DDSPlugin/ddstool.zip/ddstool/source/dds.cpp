#include <windows.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <commdlg.h>
#include <stdio.h>
#include <process.h>
#include <direct.h>
#include <string.h>

static char gWorkDirectory[1024];

int CreateDDS(const char *fname,bool alpha)
{
  const char *arg[6];

  char scratch[2048];
  sprintf(scratch,"%s\\s3tc.exe",gWorkDirectory);

  arg[0] = scratch;
  arg[1] = "/M";

  if ( alpha )
    arg[2] = "/5";
  else
    arg[2] = "/1";

  arg[3] = fname;
  arg[4] = 0;

  int ret = _spawnv(_P_WAIT,scratch,arg);

  Sleep(100);

  return ret;

}



// Function name        :OPT_SelectFile
// Description      :
//
// Return type          : BOOL
// Argument         : HWND hWndParent           - handle to the owner window - can be NULL
// Argument         : char* pszDestBuffer               - Destination buffer to store the selected file & path. Assumed to be 256 chars

// Argument         : const char* pszInitialDir               - initial directory to display. Can be empty string
// Argument         : const char* pszTitle                    - title for the dialog, e.g "Select source file to use"
BOOL OPT_SelectFile(HWND hWndParent, char* pszDestBuffer, const char* pszInitialDir, const char* pszTitle)
{
  OPENFILENAME ofn;



  char szFilter[1024] = "Image Files (*.bmp,*.tga)\0*.bmp;*.tga\0\0";

  // seems that dest buffer must be null terminated for GetOpenFileName.....
  *pszDestBuffer = '\0';

  memset(&ofn, 0, sizeof(ofn));

        ofn.lStructSize = sizeof(OPENFILENAME);
        ofn.hwndOwner = hWndParent;
        ofn.lpstrFilter = szFilter;

        ofn.lpstrInitialDir = pszInitialDir;
        ofn.hInstance = NULL;
        ofn.lpstrTitle = pszTitle;
        ofn.lpstrFileTitle = NULL;
        ofn.lpstrFile = pszDestBuffer;
        ofn.nMaxFile = 32768;
        ofn.lpstrDefExt = "";
        ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT;

        BOOL bRet = GetOpenFileName(&ofn);

        if (0 == bRet)
        {
                DWORD dwError = CommDlgExtendedError();
                //_ASSERTE(SUCCEEDED(dwError));
        }

        return bRet;
}


const char * GetNextString(const char *next)
{
  if ( *next == 0 ) return 0;
  while ( *next ) next++;
  next++;
  if ( *next == 0 ) return 0;
  return next;
}

int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hInstPrev, TCHAR* pszCmdLine, int nShowCmd )
{

  _getcwd(gWorkDirectory,1024);

  char scratch[2048];
  sprintf(scratch,"%s\\s3tc.exe",gWorkDirectory);


  char szDestBuffer[32768];
  memset(szDestBuffer,32768,0);

  OPT_SelectFile(NULL, szDestBuffer, "c:\\", "Select Files To Convert To .DDS File Format");


  const char *next = GetNextString(szDestBuffer);

  FILE *fph = fopen("dds.log", "wb");

  while ( next )
  {
    int len = strlen(next);
    if ( len > 4 )
    {
      bool alpha = false;
      if ( stricmp( &next[len-4],".tga") == 0 )  alpha = true;
      int ret = CreateDDS(next,alpha);
      fprintf(fph,"CreateDDS: %s RetCode: %d Alpha: %d\n",next,ret,alpha);

    }
    next = GetNextString(next);
  }

  fclose(fph);

  return 0;
}
